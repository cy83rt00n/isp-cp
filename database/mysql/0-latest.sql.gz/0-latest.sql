-- MariaDB dump 10.17  Distrib 10.4.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ispcp
-- ------------------------------------------------------
-- Server version	10.4.8-MariaDB-1:10.4.8+maria~bionic

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ispcp`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ispcp` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `ispcp`;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issues` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `report_date` int(10) NOT NULL,
  `resolve_date` int(10) NOT NULL,
  `comment` text COLLATE utf8mb4_bin DEFAULT NULL,
  `reporter` int(10) DEFAULT NULL,
  `resolver` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (31,1570314167,0,'{&#34;address&#34;:{&#34;city&#34;:{&#34;title&#34;:&#34;Люберцы&#34;,&#34;id&#34;:&#34;6&#34;},&#34;street&#34;:{&#34;title&#34;:&#34;Митрофанова&#34;,&#34;id&#34;:&#34;8&#34;},&#34;home&#34;:{&#34;title&#34;:&#34;45&#34;,&#34;id&#34;:&#34;16&#34;},&#34;flat&#34;:{&#34;title&#34;:&#34;34&#34;,&#34;id&#34;:&#34;22&#34;}},&#34;engineer&#34;:{&#34;title&#34;:&#34;Сидоров&#34;,&#34;id&#34;:&#34;26&#34;},&#34;comment&#34;:&#34;&#34;,&#34;report_status&#34;:{},&#34;execution_date&#34;:1571270400,&#34;history&#34;:[&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{\\&#34;title\\&#34;:\\&#34;Люберцы\\&#34;,\\&#34;id\\&#34;:\\&#34;6\\&#34;},\\&#34;street\\&#34;:{\\&#34;title\\&#34;:\\&#34;Митрофанова\\&#34;,\\&#34;id\\&#34;:\\&#34;8\\&#34;},\\&#34;home\\&#34;:{\\&#34;title\\&#34;:\\&#34;45\\&#34;,\\&#34;id\\&#34;:\\&#34;16\\&#34;},\\&#34;flat\\&#34;:{\\&#34;title\\&#34;:\\&#34;34\\&#34;,\\&#34;id\\&#34;:\\&#34;22\\&#34;}},\\&#34;engineer\\&#34;:{\\&#34;title\\&#34;:\\&#34;Сидоров\\&#34;,\\&#34;id\\&#34;:\\&#34;26\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:null}&#34;,&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{\\&#34;title\\&#34;:\\&#34;Люберцы\\&#34;,\\&#34;id\\&#34;:\\&#34;6\\&#34;},\\&#34;street\\&#34;:{\\&#34;title\\&#34;:\\&#34;Митрофанова\\&#34;,\\&#34;id\\&#34;:\\&#34;8\\&#34;},\\&#34;home\\&#34;:{\\&#34;title\\&#34;:\\&#34;45\\&#34;,\\&#34;id\\&#34;:\\&#34;16\\&#34;},\\&#34;flat\\&#34;:{\\&#34;title\\&#34;:\\&#34;34\\&#34;,\\&#34;id\\&#34;:\\&#34;22\\&#34;}},\\&#34;engineer\\&#34;:{\\&#34;title\\&#34;:\\&#34;Сидоров\\&#34;,\\&#34;id\\&#34;:\\&#34;26\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:1571270400}&#34;]}',0,0),(32,1570314178,0,'{&#34;address&#34;:{&#34;city&#34;:{&#34;title&#34;:&#34;Люберцы&#34;,&#34;id&#34;:&#34;6&#34;},&#34;street&#34;:{&#34;title&#34;:&#34;Митрофанова&#34;,&#34;id&#34;:&#34;8&#34;},&#34;home&#34;:{&#34;title&#34;:&#34;44&#34;,&#34;id&#34;:&#34;15&#34;},&#34;flat&#34;:{&#34;title&#34;:&#34;1&#34;,&#34;id&#34;:&#34;19&#34;}},&#34;engineer&#34;:{&#34;title&#34;:&#34;Сидоров&#34;,&#34;id&#34;:&#34;26&#34;},&#34;comment&#34;:&#34;&#34;,&#34;report_status&#34;:{},&#34;execution_date&#34;:null,&#34;history&#34;:[&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{\\&#34;title\\&#34;:\\&#34;Люберцы\\&#34;,\\&#34;id\\&#34;:\\&#34;6\\&#34;},\\&#34;street\\&#34;:{\\&#34;title\\&#34;:\\&#34;Митрофанова\\&#34;,\\&#34;id\\&#34;:\\&#34;8\\&#34;},\\&#34;home\\&#34;:{\\&#34;title\\&#34;:\\&#34;44\\&#34;,\\&#34;id\\&#34;:\\&#34;15\\&#34;},\\&#34;flat\\&#34;:{\\&#34;title\\&#34;:\\&#34;1\\&#34;,\\&#34;id\\&#34;:\\&#34;19\\&#34;}},\\&#34;engineer\\&#34;:{\\&#34;title\\&#34;:\\&#34;Сидоров\\&#34;,\\&#34;id\\&#34;:\\&#34;26\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:1570579200}&#34;,&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{\\&#34;title\\&#34;:\\&#34;Люберцы\\&#34;,\\&#34;id\\&#34;:\\&#34;6\\&#34;},\\&#34;street\\&#34;:{\\&#34;title\\&#34;:\\&#34;Митрофанова\\&#34;,\\&#34;id\\&#34;:\\&#34;8\\&#34;},\\&#34;home\\&#34;:{\\&#34;title\\&#34;:\\&#34;44\\&#34;,\\&#34;id\\&#34;:\\&#34;15\\&#34;},\\&#34;flat\\&#34;:{\\&#34;title\\&#34;:\\&#34;1\\&#34;,\\&#34;id\\&#34;:\\&#34;19\\&#34;}},\\&#34;engineer\\&#34;:{\\&#34;title\\&#34;:\\&#34;Сидоров\\&#34;,\\&#34;id\\&#34;:\\&#34;26\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:null}&#34;,&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{\\&#34;title\\&#34;:\\&#34;Люберцы\\&#34;,\\&#34;id\\&#34;:\\&#34;6\\&#34;},\\&#34;street\\&#34;:{\\&#34;title\\&#34;:\\&#34;Митрофанова\\&#34;,\\&#34;id\\&#34;:\\&#34;8\\&#34;},\\&#34;home\\&#34;:{\\&#34;title\\&#34;:\\&#34;44\\&#34;,\\&#34;id\\&#34;:\\&#34;15\\&#34;},\\&#34;flat\\&#34;:{\\&#34;title\\&#34;:\\&#34;1\\&#34;,\\&#34;id\\&#34;:\\&#34;19\\&#34;}},\\&#34;engineer\\&#34;:{\\&#34;title\\&#34;:\\&#34;Сидоров\\&#34;,\\&#34;id\\&#34;:\\&#34;26\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:null}&#34;]}',0,0),(33,1570357072,0,'{&#34;address&#34;:{&#34;city&#34;:{},&#34;street&#34;:{},&#34;home&#34;:{},&#34;flat&#34;:{}},&#34;engineer&#34;:{&#34;id&#34;:0,&#34;title&#34;:&#34;&#34;},&#34;comment&#34;:&#34;&#34;,&#34;report_status&#34;:{},&#34;execution_date&#34;:null,&#34;history&#34;:[&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{},\\&#34;street\\&#34;:{},\\&#34;home\\&#34;:{},\\&#34;flat\\&#34;:{}},\\&#34;engineer\\&#34;:{\\&#34;id\\&#34;:0,\\&#34;title\\&#34;:\\&#34;\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:null}&#34;]}',0,0),(34,1570357090,0,'{&#34;address&#34;:{&#34;city&#34;:{},&#34;street&#34;:{},&#34;home&#34;:{},&#34;flat&#34;:{}},&#34;engineer&#34;:{&#34;id&#34;:0,&#34;title&#34;:&#34;&#34;},&#34;comment&#34;:&#34;&#34;,&#34;report_status&#34;:{},&#34;execution_date&#34;:null,&#34;history&#34;:[&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{},\\&#34;street\\&#34;:{},\\&#34;home\\&#34;:{},\\&#34;flat\\&#34;:{}},\\&#34;engineer\\&#34;:{\\&#34;id\\&#34;:0,\\&#34;title\\&#34;:\\&#34;\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:null}&#34;]}',0,0),(35,1570362544,0,'{&#34;address&#34;:{&#34;city&#34;:{},&#34;street&#34;:{},&#34;home&#34;:{},&#34;flat&#34;:{}},&#34;engineer&#34;:{&#34;id&#34;:0,&#34;title&#34;:&#34;&#34;},&#34;comment&#34;:&#34;&#34;,&#34;report_status&#34;:{},&#34;execution_date&#34;:null,&#34;history&#34;:[&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{},\\&#34;street\\&#34;:{},\\&#34;home\\&#34;:{},\\&#34;flat\\&#34;:{}},\\&#34;engineer\\&#34;:{\\&#34;id\\&#34;:0,\\&#34;title\\&#34;:\\&#34;\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:null}&#34;]}',1,0),(36,1570365738,0,'{&#34;address&#34;:{&#34;city&#34;:{},&#34;street&#34;:{},&#34;home&#34;:{},&#34;flat&#34;:{}},&#34;engineer&#34;:{&#34;id&#34;:0,&#34;title&#34;:&#34;&#34;},&#34;comment&#34;:&#34;&#34;,&#34;report_status&#34;:{},&#34;execution_date&#34;:null,&#34;history&#34;:[&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{},\\&#34;street\\&#34;:{},\\&#34;home\\&#34;:{},\\&#34;flat\\&#34;:{}},\\&#34;engineer\\&#34;:{\\&#34;id\\&#34;:0,\\&#34;title\\&#34;:\\&#34;\\&#34;},\\&#34;comment\\&#34;:\\&#34;\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:null}&#34;]}',2,0),(37,1570365801,0,'{&#34;address&#34;:{&#34;city&#34;:{&#34;title&#34;:&#34;Люберцы&#34;,&#34;id&#34;:&#34;6&#34;},&#34;street&#34;:{&#34;title&#34;:&#34;Митрофанова&#34;,&#34;id&#34;:&#34;8&#34;},&#34;home&#34;:{&#34;title&#34;:&#34;44&#34;,&#34;id&#34;:&#34;15&#34;},&#34;flat&#34;:{&#34;title&#34;:&#34;2&#34;,&#34;id&#34;:&#34;20&#34;}},&#34;engineer&#34;:{&#34;title&#34;:&#34;Сидоров&#34;,&#34;id&#34;:&#34;26&#34;},&#34;comment&#34;:&#34;qazwsxedc yuikjnbvc&#34;,&#34;report_status&#34;:{},&#34;execution_date&#34;:1571184000,&#34;history&#34;:[&#34;{\\&#34;address\\&#34;:{\\&#34;city\\&#34;:{\\&#34;title\\&#34;:\\&#34;Люберцы\\&#34;,\\&#34;id\\&#34;:\\&#34;6\\&#34;},\\&#34;street\\&#34;:{\\&#34;title\\&#34;:\\&#34;Митрофанова\\&#34;,\\&#34;id\\&#34;:\\&#34;8\\&#34;},\\&#34;home\\&#34;:{\\&#34;title\\&#34;:\\&#34;44\\&#34;,\\&#34;id\\&#34;:\\&#34;15\\&#34;},\\&#34;flat\\&#34;:{\\&#34;title\\&#34;:\\&#34;2\\&#34;,\\&#34;id\\&#34;:\\&#34;20\\&#34;}},\\&#34;engineer\\&#34;:{\\&#34;title\\&#34;:\\&#34;Сидоров\\&#34;,\\&#34;id\\&#34;:\\&#34;26\\&#34;},\\&#34;comment\\&#34;:\\&#34;qazwsxedc yuikjnbvc\\&#34;,\\&#34;report_status\\&#34;:{},\\&#34;execution_date\\&#34;:1571184000}&#34;]}',3,0);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `value` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terms`
--

DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terms` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `parentId` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terms`
--

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` VALUES (1,'root','Адреса',0),(6,'adresa','Люберцы',1),(7,'root','Лыткарино',1),(8,'lyubercy','Митрофанова',6),(9,'root','Ленина',6),(10,'lytkarino','Ленина',7),(11,'root','Монтажники',0),(12,'montazhniki','Петров',11),(15,'mitrofanova','44',8),(16,'mitrofanova','45',8),(17,'mitrofanova','46',8),(18,'mitrofanova','47',8),(19,'44','1',15),(20,'44','2',15),(21,'45','11',16),(22,'45','34',16),(23,'46','33',17),(24,'47','54',18),(26,'montazhniki','Сидоров',11),(27,'montazhniki','Иванов',11),(28,'root','Статусы заявок',0),(29,'statusy-zayavok','Новая',28),(30,'statusy-zayavok','В работе',28),(31,'statusy-zayavok','Решена',28),(32,'statusy-zayavok','Обзвон',28);
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `roleId` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@isp.cp','e10adc3949ba59abbe56e057f20f883e',999),(2,'manager@isp.cp','e10adc3949ba59abbe56e057f20f883e',993),(3,'engineer@isp.cp','e10adc3949ba59abbe56e057f20f883e',992);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-06 13:02:23
